from django.apps import AppConfig


class CalorietrackerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calorietracker'
