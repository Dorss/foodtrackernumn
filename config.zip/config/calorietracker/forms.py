from django import forms 
from .models import *


class selectfoodForm(forms.ModelForm):
    
    class Meta:
        model = Selectfooditem
        fields = "__all__"

    #filtering fooditem selection to user's food items
    def __init__(self, user, *args, **kwargs):
        super(selectfoodForm, self).__init__(*args, **kwargs)
        self.fields['name'].queryset = Fooditem.objects.filter(person=user)