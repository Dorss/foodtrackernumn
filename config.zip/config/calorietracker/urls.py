from django.urls import path
from .views import FoodItemCreateView,FoodItemListView,FoodItemDeleteView,SelectFoodCreateView,DeleteFoodView,ProfileView,EditCalorielimitView

urlpatterns = [
    path('fooditem_create/', FoodItemCreateView.as_view(), name='fooditem_create'),
    path('fooditem_list/', FoodItemListView.as_view(), name='fooditem_list'),
    path('fooditem_delete/<int:pk>', FoodItemDeleteView.as_view(), name='fooditem_delete'),
    path('addfood_create/', SelectFoodCreateView, name='addfood_create'),
    path('deletefood_delete/<int:pk>', DeleteFoodView.as_view(), name='deletefood_delete'),
    path('profile/', ProfileView, name='profile'),
   path('calorielimit_edit/<int:pk>', EditCalorielimitView.as_view(), name='calorielimit_edit'),
]