from .forms import *
from django.urls import reverse_lazy,reverse
from .models import *
from accounts.models import CustomUser
from django.views import generic
from django.views.generic import ListView,CreateView
from django.views.generic.edit import UpdateView
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin



class FoodItemCreateView(LoginRequiredMixin, CreateView):
    model = Fooditem
    template_name = 'fooditem_create.html'
    fields = "__all__"
    success_url = reverse_lazy('fooditem_list')
    
    


class FoodItemListView(LoginRequiredMixin,ListView):
    model = Fooditem
    template_name = 'fooditem_list.html'
    fields = "__all__"

    
class FoodItemDeleteView(LoginRequiredMixin,generic.DeleteView):
    model = Fooditem
    template_name = 'fooditem_delete.html'
    success_url = reverse_lazy('fooditem_list.html')



@login_required(login_url='login')
def SelectFoodCreateView(request):
    usernow = CustomUser.objects.get(id=request.user.id)
    form = selectfoodForm(request.user, instance=usernow)

    if request.method == "POST":
        form = selectfoodForm(request.user, request.POST, instance=usernow)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            category = form.cleaned_data.get('category')
            quantity = form.cleaned_data.get('quantity')
            person = form.cleaned_data.get('person')
            selectedfood = Selectfooditem.objects.create(
                name=name, quantity=quantity, category=category, person=person)
            selectedfood.save()
            return redirect('/manage/profile')
        else:
            form = selectfoodForm(request.user)
    context = {'form': form}
    return render(request, 'addfood_create.html', context)

@login_required(login_url='login')
def ProfileView(request):
    usernow = CustomUser.objects.get(id=request.user.id)
    calorielimit = usernow.calorielimit
    selectedfood = Selectfooditem.objects.filter(person=request.user)
    
    calorieconsumed = 0
    calorieleft = calorielimit

    for food in selectedfood :
        calorieconsumed+= (food.name.calorie * food.quantity)
        calorieleft = calorielimit - calorieconsumed

    
    context = {'selectedfood':selectedfood ,'Calorielimit':calorielimit , 'Calorieconsumed': calorieconsumed , 'calorieleft' : calorieleft}

    return render(request, 'profile.html', context)
    

class DeleteFoodView(LoginRequiredMixin,generic.DeleteView):
    model = Selectfooditem
    template_name = 'deletefoodview_delete.html'
    success_url = reverse_lazy('profile')


# @login_required(login_url='login')
# def EditCalorielimitView(request):
#     if request.method == 'POST':
#         user = CustomUser.objects.get(id=request.user.id)
#         user.calorielimit = request.POST.get('calorielimit')
#         user.save()
#         return redirect('manage/profile')

#     return render(request, 'calorielimit_edit.html')

class EditCalorielimitView (LoginRequiredMixin,UpdateView):
    model = CustomUser
    template_name= 'calorielimit_edit.html'
    fields=['calorielimit']
    success_url= reverse_lazy('profile')
